package com.example.app01

data class itemWork (
    var id : Int,
    var id_job : Int,
    var date : String,
    var color : Int,
    var pay_total : Int,
    var pay_extra : Int,
    var time : Int,
    var pay : Int,
    var time_start : Int,
    var time_end : Int,
    var time_rest_start : Int,
    var time_rest_end : Int,
    var insurance : Boolean,
    var extra : Boolean,
    var extend : Boolean,
    var night : Boolean
)