package com.example.app01

data class itemAnnouncement (
    var id : Int,
    var id_boss : Int,
    var title : String,
    var desc : String,
    var close : Boolean
)