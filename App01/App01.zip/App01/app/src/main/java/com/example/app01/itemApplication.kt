package com.example.app01

data class itemApplication  (
    var id : Int,
    var id_jobhunting : Int,
    var id_worker : Int
)