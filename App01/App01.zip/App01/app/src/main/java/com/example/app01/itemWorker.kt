package com.example.app01

data class itemWorker (
    var id : Int,
    var id_branch : Int, // id for branch
    var id_worker : Int // id for worker
)