package com.example.app01

data class itemBranch (
    var id : Int,
    var title : String,
    var id_boss : Int // id for boss
)